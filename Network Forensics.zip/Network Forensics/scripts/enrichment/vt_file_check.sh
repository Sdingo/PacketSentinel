#!/bin/bash
source ../../.api_keys
HASH=$1
curl -s "https://www.virustotal.com/api/v3/files/$HASH" \
  -H "x-apikey: $VT_API_KEY" | \
  jq '{hash: .data.id, malicious: .data.attributes.last_analysis_stats.malicious, type: .data.attributes.type_description, name: .data.attributes.names[0], size: .data.attributes.size}'
