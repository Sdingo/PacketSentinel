#!/bin/bash
source ../../.api_keys
IP=$1
curl -s "https://www.virustotal.com/api/v3/ip_addresses/$IP" \
  -H "x-apikey: $VT_API_KEY" | \
  jq '{ip: .data.id, malicious: .data.attributes.last_analysis_stats.malicious, suspicious: .data.attributes.last_analysis_stats.suspicious, harmless: .data.attributes.last_analysis_stats.harmless, country: .data.attributes.country, as_owner: .data.attributes.as_owner}'
sleep 16
