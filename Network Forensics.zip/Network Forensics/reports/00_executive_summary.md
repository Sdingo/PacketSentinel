# 🛡️ PacketSentinel - Lokibot Infection Analysis

**Project:** Network Forensics & Threat Hunting  
**Analyst:** Phiwokuhle Sdingo Kunene  
**Analysis Date:** October 23, 2025  
**PCAP Source:** Malware-Traffic-Analysis.net  
**Infection Date:** October 12, 2020

---

## Executive Summary

Comprehensive network forensic analysis of Lokibot infostealer trojan infection, revealing complete attack chain from initial payload delivery through C2 establishment and data exfiltration. Analysis identified characteristic 60-second beaconing pattern, extracted malware binary (63/70+ AV detections), and created 8 production-grade detection signatures.

**Key Achievement:** Reconstructed entire attack timeline from network traffic alone, demonstrating advanced PCAP analysis and threat hunting capabilities.

---

## Critical Findings

### Victim Profile
- **Internal IP:** 10.10.12.101
- **Operating System:** Windows 10 (inferred from user-agent)
- **Infection Vector:** Malicious executable download via HTTP
- **Infection Duration:** 693 seconds (~11.5 minutes captured)
- **Status:** CRITICALLY COMPROMISED

### Malicious Infrastructure

| Indicator | Type | VT Detections | Hosting | Role |
|-----------|------|---------------|---------|------|
| **millsmiltinon.com** | Domain | 13/90 malicious | Unknown | Malware distribution |
| **104.223.143.132** | IP | 10/63 malicious | AMAZON-02 (US) | Primary C2 server |
| **45.14.112.133** | IP | 0/61 (false negative) | VeloxServ (UK) | Data exfiltration |

**Infrastructure Notes:**
- C2 hosted on Amazon AWS (sophisticated threat actor using legitimate cloud)
- Exfiltration server shows 0 VT detections but confirmed malicious via PCAP
- Multi-stage infrastructure (separate C2 vs exfiltration = operational security)

### Extracted Malware

**Primary Payload:**
- **Filename:** Xehmigm.exe
- **Type:** PE32 executable (Win32 EXE)
- **Size:** 629,760 bytes (615 KB)
- **SHA256:** `6b53ba14172f0094a00edfef96887aab01e8b1c49bdc6b1f34d7f2e32f88d172`
- **VT Detection:** **63/70+ vendors (90% detection rate)**
- **Original Name:** 2020-10-12-Windows-EXE-for-Lokibot.bin
- **Status:** ✅ CONFIRMED LOKIBOT INFOSTEALER

**Secondary File:**
- **Filename:** Xehmuth (594 KB)
- **Type:** ASCII text (possibly encoded configuration)
- **SHA256:** `b1fd9868dc4dd1a07baed3572143e945ca66fea3f542bbf8d98c9b96032542f9`

---

## Attack Timeline

| Time (EDT) | Event | Evidence | MITRE Technique |
|------------|-------|----------|-----------------|
| **17:02:18** | Initial malware download | GET /Xehmigm.exe from millsmiltinon.com | T1566.001 |
| **17:02:28** | Windows Update check | Legitimate ctldl.windowsupdate.com | N/A |
| **17:02:53** | Malware execution | Suspicious "PPPPPX" user-agent appears | T1204.002 |
| **17:02:58** | C2 establishment | 3 rapid POST to 104.223.143.132/ecflix/Panel/five/fre.php | T1071.001 |
| **17:03:59** | Regular beaconing begins | POST every 60 seconds (clockwork precision) | T1071.001 |
| **17:02:58+** | Data exfiltration | 1.3 MB transferred to 45.14.112.133 | T1041 |

**Time from Download to C2:** 40 seconds (rapid infection)  
**Total Beacons Captured:** 14 (in 11.5 minutes)

---

## C2 Communication Analysis

### Beaconing Pattern (Signature Behavior)

**Characteristic:** Exactly 60-second intervals (automated malware behavior)
```
17:02:58 ─┬─ Initial check-in (3 rapid beacons)
          │
17:03:59 ─┼─ Regular beacon (+61 seconds)
          │
17:05:00 ─┼─ Regular beacon (+61 seconds)
          │
17:06:00 ─┼─ Regular beacon (+60 seconds)
          │
17:07:00 ─┼─ Regular beacon (+60 seconds)
          │
   ...    ─┴─ Continues with machine-like precision
```

**C2 Infrastructure Details:**
- **Primary Server:** 104.223.143.132
- **C2 Panel Path:** `/ecflix/Panel/five/fre.php`
- **Method:** HTTP POST (unencrypted)
- **User-Agent Fingerprint:** "PPPPPX" (unique Lokibot signature)
- **Response Size:** 23 bytes (minimal acknowledgment)

**Traffic Volume:**
- To 104.223.143.132: 1,262 packets, 1.3 MB
- To 45.14.112.133: 160 packets, 21 KB
- Large data transfer indicates screenshot/keylog exfiltration

---

## Indicators of Compromise (IOCs)

### Network IOCs

**Malicious IP Addresses:**
```
104.223.143.132  (Primary C2 - AMAZON-02 AWS)
45.14.112.133    (Exfiltration - VeloxServ UK)
```

**Malicious Domains:**
```
millsmiltinon.com (Malware distribution)
```

**C2 Behavioral Signatures:**
```
URI Pattern:    /ecflix/Panel/five/fre.php
User-Agent:     PPPPPX
User-Agent:     Mozilla/4.08 (Charon; Inferno)
Beacon Interval: 60 seconds
Method:         HTTP POST
```

### File IOCs

**Malware Binary:**
```
SHA256: 6b53ba14172f0094a00edfef96887aab01e8b1c49bdc6b1f34d7f2e32f88d172
MD5:    [AVAILABLE IF NEEDED]
```

**Download URL:**
```
http://millsmiltinon.com/ojHYhkfkmuofwuendkfptktnbujgmfkgtdeitobregvdgetyhsk/Xehmigm.exe
```

---

## MITRE ATT&CK Mapping

### Techniques Identified (9 Total)

| Tactic | Technique ID | Technique Name | Evidence | Confidence |
|--------|--------------|----------------|----------|------------|
| **Initial Access** | T1566.001 | Phishing: Spearphishing Attachment | User downloaded malicious .exe | HIGH |
| **Execution** | T1204.002 | User Execution: Malicious File | User executed Xehmigm.exe | HIGH |
| **Command & Control** | T1071.001 | Application Layer Protocol: Web | HTTP POST beaconing to C2 | CONFIRMED |
| **Collection** | T1056.001 | Input Capture: Keylogging | Lokibot known capability + data exfil | HIGH |
| **Collection** | T1113 | Screen Capture | 1.3 MB exfiltration suggests screenshots | MEDIUM |
| **Exfiltration** | T1041 | Exfiltration Over C2 Channel | Data sent via POST to C2 servers | CONFIRMED |
| **Exfiltration** | T1567.001 | Exfiltration Over Web Service | DNS query to discord.com | MEDIUM |
| **Defense Evasion** | T1027 | Obfuscated Files or Information | Randomized download URL path | MEDIUM |
| **Persistence** | T1547.001 | Registry Run Keys (inferred) | Typical Lokibot behavior | LOW |

**ATT&CK Coverage:** 6 tactics, 9 techniques  
**Navigator Layer:** Created for defensive gap analysis

---

## Detection Engineering

### Signatures Created (8 Total)

#### Suricata IDS Rules (5 Signatures)
```
1. Lokibot C2 Beacon to Known Panel (sid:8000001)
   - Detects POST to 104.223.143.132/ecflix/Panel/five/fre.php
   
2. Suspicious User-Agent "PPPPPX" (sid:8000002)
   - Unique Lokibot fingerprint
   
3. Malware Download from millsmiltinon.com (sid:8000003)
   - Blocks .exe downloads from known malicious domain
   
4. Regular 60-Second Beaconing Pattern (sid:8000004)
   - Behavioral detection for clockwork C2 traffic
   
5. Secondary C2 Server Communication (sid:8000005)
   - Alerts on traffic to 45.14.112.133
```

#### Sigma SIEM Rule (1 Rule)
```yaml
Title: Lokibot 60-Second C2 Beaconing Pattern
Detection: 8+ connections to malicious IPs in 10 minutes
Level: CRITICAL
Use Case: SIEM correlation for firewall/proxy logs
```

#### YARA Patterns (2 Rules)
```
1. Lokibot_C2_Traffic_Pattern
   - Detects /ecflix/Panel/five/fre.php + PPPPPX user-agent
   
2. Lokibot_Download_URL
   - Identifies millsmiltinon.com download patterns
```

### Detection Deployment

**Suricata:**
```bash
suricata -c /etc/suricata/suricata.yaml -S IOCs/suricata/lokibot_signatures.rules -i eth0
```

**Splunk (Sigma):**
```spl
index=firewall dest_ip IN (104.223.143.132, 45.14.112.133) dest_port=80
| stats count by src_ip
| where count > 8
```

**YARA (Network Traffic):**
```bash
yara IOCs/yara/lokibot_traffic.yar captured_traffic.pcap
```

---

## Threat Intelligence Correlation

### VirusTotal Analysis Summary

| Indicator | Detection Rate | Status |
|-----------|---------------|--------|
| Xehmigm.exe | 63/70+ (90%) | CONFIRMED MALWARE |
| millsmiltinon.com | 13/90 (14%) | MALICIOUS DOMAIN |
| 104.223.143.132 | 10/63 (16%) | MALICIOUS IP |
| 45.14.112.133 | 0/61 (0%) | FALSE NEGATIVE |

**Key Insight:** 45.14.112.133 shows why VT alone insufficient - PCAP proves malicious activity despite 0 detections.

### Infrastructure Analysis

**104.223.143.132 (Primary C2):**
- Hosted: Amazon AWS (AMAZON-02)
- Country: United States
- **Implication:** Sophisticated actor using legitimate cloud infrastructure

**45.14.112.133 (Exfiltration):**
- Hosted: VeloxServ Communications Ltd
- Country: United Kingdom
- **Likely:** Compromised server or newly established infrastructure

---

## Recommendations

### Immediate Actions (< 24 Hours)

1. ✅ **Isolate Infected Host**
   - IP: 10.10.12.101
   - Disconnect from network immediately
   - Perform forensic imaging before remediation

2. ✅ **Block IOCs at Perimeter**
```
   Firewall rules:
   - block ip 104.223.143.132
   - block ip 45.14.112.133
   - block domain millsmiltinon.com
```

3. ✅ **Deploy Detection Signatures**
   - Suricata: 5 rules to IDS
   - Sigma: SIEM correlation rule
   - YARA: Network traffic scanning

4. ✅ **Threat Hunt in SIEM**
```
   Search criteria:
   - 60-second beaconing patterns
   - User-agent "PPPPPX"
   - Connections to IOC IPs/domains
   - HTTP POST to *.php endpoints every minute
```

### Short-Term (< 1 Week)

5. ✅ **Endpoint Forensics**
   - Memory dump analysis
   - Registry persistence check (HKCU/HKLM Run keys)
   - Extract keylog/screenshot data if possible
   - Identify initial infection vector (email, web, USB)

6. ✅ **Email Investigation**
   - Search for phishing emails with malicious links
   - Identify other recipients in organization
   - Quarantine/remove from all mailboxes

7. ✅ **User Awareness**
   - Security training for affected user
   - Organization-wide phishing awareness campaign
   - Emphasize risks of downloading executables

### Long-Term (Strategic)

8. ✅ **Email Gateway Hardening**
   - Sandbox all attachments and links before delivery
   - Block .exe downloads via webmail
   - Implement DMARC/SPF/DKIM

9. ✅ **EDR Deployment**
   - Real-time process/network monitoring
   - Behavioral detection for C2 beaconing
   - Automatic isolation of suspected compromises

10. ✅ **Network Segmentation**
    - Limit lateral movement potential
    - Segment critical assets
    - Implement zero-trust architecture

---

## Lessons Learned

### What Worked Well
- ✅ PCAP captured complete infection chain
- ✅ 60-second beaconing easily identifiable
- ✅ Unencrypted HTTP provided clear visibility
- ✅ IOC extraction and correlation successful

### Gaps Identified
- ⚠️ Email gateway failed to block malicious download
- ⚠️ No endpoint detection triggered on execution
- ⚠️ User clicked malicious link (training gap)
- ⚠️ No network anomaly detection for beaconing

### Technical Insights
1. **Beaconing = Fingerprint:** Regular intervals easy to detect with proper monitoring
2. **Cloud Abuse:** Threat actors using AWS complicates IP-based blocking
3. **VT Limitations:** Behavioral analysis trumps reputation scores
4. **User-Agent IOC:** "PPPPPX" is unique and highly valuable indicator

---

## Conclusion

Lokibot infection successfully reconstructed from network traffic analysis alone, demonstrating:
- Complete attack chain visibility (download → execution → C2 → exfiltration)
- Effective IOC extraction and threat intelligence correlation
- Production-grade detection signature development (8 rules)
- MITRE ATT&CK mapping for defensive gap analysis (9 techniques)

**Final Assessment:**
- **Severity:** CRITICAL
- **Confidence:** HIGH (90%+ based on multi-source validation)
- **Status:** IOCs blocked, detection rules deployed, incident contained

**Project Value:** Demonstrates advanced network forensics, threat hunting, and detection engineering capabilities essential for SOC analyst and threat intelligence roles.

---

**Analyst:** Phiwokuhle Sdingo Kunene  
**Project:** PacketSentinel - Network Threat Hunting  
**Linkedin:** https://www.linkedin.com/in/phiwokuhlesdingo/ 


